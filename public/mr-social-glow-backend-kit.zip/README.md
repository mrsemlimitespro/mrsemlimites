# MR Sem Limites — Extension Master Kit (MR Social Glow v17.0)

Base: https://mrsemlimites.lovable.app

## Endpoints
POST /api/public/validar-licenca
POST /api/public/ext/functions/v1/validate-license-v2
POST /api/public/licenca/heartbeat
POST /api/public/licenca/config
OPTIONS suportado em todas (CORS chrome-extension://*)

## Formatos de chave
MR:          /^MR-[A-Z0-9]{4}(?:-[A-Z0-9]{4}){2}$/     -> MR-XXXX-XXXX-XXXX
Tradicional: /^[A-Z0-9]{5}(?:-[A-Z0-9]{5}){3}$/        -> XXXXX-XXXXX-XXXXX-XXXXX

Normalização central: lib/utils.ts -> normalizeLicenseKey()
(NFKC, remove zero-width, hífens Unicode -> ASCII, trim, uppercase)

## Resposta
Sucesso: {ok:true, valid:true, premium:true, tipo, expira_em, expires_in, cliente_id}
Falha:   {ok:false, valid:false, error:"Licença inválida ou expirada."}  (HTTP 200)

## Variáveis
Ver .env.example. Nenhum segredo incluído neste pacote.
