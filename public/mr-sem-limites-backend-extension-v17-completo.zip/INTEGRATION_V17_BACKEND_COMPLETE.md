# INTEGRATION V17.0 BACKEND COMPLETE

Backend isolado em /api/public/ext-v17/*
Proxying real para Lovable preservando payloads.
Validação HWID e Licença MR.

