# Backend MR Sem Limites - Extensão v17.0
Implementação oficial compatível com a extensão Chrome Manifest V3.

## Rotas Principais
- /api/public/ext-v17/validate-license
- /api/public/ext-v17/heartbeat
- /api/public/ext-v17/send-command
- /api/public/ext-v17/fix-stream
- /api/public/ext-v17/upload
- /api/public/ext-v17/process-payment

## Segurança
- CORS restrito a chrome-extension:// e localhost.
- Validação HWID e Expiração.
- Registro de auditoria em ext_v17_requests e ext_v17_sessions.