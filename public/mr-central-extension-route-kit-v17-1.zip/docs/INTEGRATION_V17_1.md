# Integração MR Central v17.1 — Ask Lovable Real-time

## Rota
`POST /api/public/ext/send-command-compatible`

## Alterações v17.1
- **Endpoint Destino**: Alterado de `/v1/send-command` para `/projects/{projectId}/chat`.
- **Preservação de Estado**: O objeto `lastPayload` enviado pelo motor da extensão é preservado integralmente, garantindo que o Lovable processe o prompt no contexto correto (threads, arquivos, elementos selecionados).
- **Normalização de Headers**: O header `Authorization` é limpo para evitar duplicação de prefixos.
- **Transparência de Erro**: O status code e o corpo da resposta do Lovable são repassados sem mascaramento, permitindo que a extensão lide com limites de créditos ou erros do servidor Lovable.
- **Metadados**: Adicionado campo `proxy: "mr-central"` para rastreamento.

## Segurança
- Validação estrita de licença (status, expiração, HWID) antes de qualquer proxy.
- Tokens Lovable nunca são registrados em logs locais.
