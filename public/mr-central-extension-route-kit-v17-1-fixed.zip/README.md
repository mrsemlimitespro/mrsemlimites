Instruções: Este kit contém a rota v17.1 com correção de headers e segurança de payload. Não utilize chaves reais em logs.
