# Contrato da Rota send-command-compatible

## Endpoint
POST /api/public/ext/send-command-compatible

## Headers Necessários
- Content-Type: application/json
- x-client-info: (opcional)
- x-extension-trace-id: (opcional)

## Payload de Entrada
JSON contendo:
- Chave de licença: user_license_key, licenseKey, license_key ou key
- Dispositivo: device_id, deviceFingerprint ou hwid
- Prompt: message ou mensagem
- Projeto: projectId ou projeto_id
- Token Lovable: token ou token_lovable
- Outros campos (anexos, lastPayload) são preservados e encaminhados.

## Respostas
- 200: Sucesso (inclui ok: true, success: true)
- 401: Licença ausente ou inválida
- 403: Licença expirada, revogada ou HWID mismatch
- 400: Payload malformado
- 502: Erro no proxy/encaminhamento para o Lovable
